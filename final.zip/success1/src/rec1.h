#include <gtk/gtk.h>

typedef struct
{
char id_client[30];
char sujet[30];
char reclamation[30];
} rec;

void afficher_rec(GtkWidget *liste);
void supp_rec(char *id);
