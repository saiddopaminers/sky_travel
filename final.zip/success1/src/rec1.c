#include <stdio.h>
#include <string.h>
#include "rec1.h"
#include <gtk/gtk.h>
#include <stdlib.h>


enum
{                ID_CLIENT,
                 SUJET,
                 RECLAMATION,
	         COLUMNS
};

void afficher_rec(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char id_client[30];
	char sujet[30];
	char reclamation[30];

	store=NULL;

	FILE *f;
	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("id_client",renderer, "text",ID_CLIENT, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("sujet",renderer, "text",SUJET, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("reclamation",renderer, "text",RECLAMATION, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);



		

		store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

		f = fopen("/home/med/Desktop/success/src/rec.txt","r");


		if(f==NULL)
		{
			return;
		}
		else
		{
			while(fscanf(f,"%s %s %s \n",id_client,sujet,reclamation)!=EOF)

			{
		gtk_list_store_append (store,&iter);

		gtk_list_store_set (store, &iter, ID_CLIENT,id_client, SUJET, sujet,RECLAMATION,reclamation,  -1);
			}
			fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref(store);
}
}
}






void supp_rec(char *id){






FILE *f;
FILE* ftemp;
char id_client[30];
	char sujet[30];
	char reclamation[30];

f = fopen("/home/med/Desktop/success/src/rec.txt","r");
ftemp = fopen("/home/med/Desktop/success/src/temp.txt","a+");
if(f==NULL)
		{
			return;
		}
		else
		{
			while(fscanf(f,"%s %s %s \n",id_client,sujet,reclamation)!=EOF)
			{if(strcmp(id,id_client)!=0)
	{fprintf(ftemp,"%s %s %s \n",id_client,sujet,reclamation);}
			}


fclose(f);
fclose(ftemp);
remove ("/home/med/Desktop/success/src/rec.txt");
rename ("/home/med/Desktop/success/src/temp.txt","/home/med/Desktop/success/src/rec.txt");






}
}




















