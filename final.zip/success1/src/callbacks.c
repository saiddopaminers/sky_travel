#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "rec1.h"

void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1;
GtkWidget *window1;
char x[50];
window1=lookup_widget(objet,"window1");
input1=lookup_widget(objet, "id_client");
strcpy(x,gtk_entry_get_text(GTK_ENTRY(input1)));
supp_rec(x);
}


void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *window1;
GtkWidget *treeview1;

window1=lookup_widget(objet,"window1");

treeview1=lookup_widget(window1,"treeview1");
afficher_rec(treeview1);


}

